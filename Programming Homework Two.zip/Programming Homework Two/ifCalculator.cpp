#include <iostream>
using namespace std;
int main() {

    // Variable Initialization

    double num1, num2;
    char sign, choice;

    // Gets numbers and operators from the user
    
    calculationProcess:
        cout << "Please enter two numbers: " << endl;
        cin >> num1 >> num2;
        cout << "Please enter an operator (+, -, *, /): " << endl;
        cin >> sign;

    // Checks if user is dividing by zero, restarts program if so

        if (num2 == 0 && sign == '/') {
            cout <<  "Invalid Input. Cannot divide by zero." << endl;
            goto calculationProcess;

    // Performs and displays calculations

        }
        if (sign == '+')
            cout << num1 << sign << num2 << " = " << num1 + num2 << endl;
        else if (sign == '-')
            cout << num1 << sign << num2 << " = " << num1 - num2 << endl;
        else if (sign == '*')
            cout << num1 << sign << num2 << " = " << num1 + num2 << endl;
        else if (sign == '/')
            cout << num1 << sign << num2 << " = " << num1 + num2 << endl;
        else{
            cout << "Invalid Input" <<  endl;
            goto calculationProcess;
        }

    // Asks user if they want to run the program again
    
        cout << "Enter 'E' to exit, or anything else to continue" << endl;
        cin >> choice;
        if (choice == 'E' or choice == 'e')
            cout << "Finished. Thank you!. " << endl;
        else
            goto calculationProcess;
}