#include <iostream>
using namespace std;
int main() {

    //Variable Initialization

    double num1, num2, result;
    char sign, choice;

    // Gets numbers and operators from the user

    calculationProcess:
        cout << "Please enter two numbers: " << endl;
        cin >> num1 >> num2;
        cout << "Please enter an operator (+, -, *, /): " << endl;
        cin >> sign;

    // Checks if user is dividing by zero, restarts program if so

        if (num2 == 0 && sign == '/') {
            cout <<  "Invalid Input. Cannot divide by zero." << endl;
            goto calculationProcess;
        }

    // Performs and displays calculations

        else {
            switch (sign){
                case '+':
                    result = num1 + num2;
                    cout << num1 << " + " << num2 << " = " << result << endl;
                    break;
                case '-':
                    result = num1 - num2;
                    cout << num1 << " - " << num2 << " = " << result << endl;
                    break;
                case '*':
                    result = num1 * num2;
                    cout << num1 << " * " << num2 << " = " << result << endl;
                    break;
                case '/':
                    result = num1 / num2;
                    cout << num1 << " / " << num2 << " = " << result << endl;
                    break;
                default:
                    cout <<"Invalid Input" << endl;
                    goto calculationProcess;
                    break;
            }

    // Asks user if they want to run the program again

            cout << "Enter 'E' to exit, or anything else to continue" << endl;
        cin >> choice;
            switch (choice){
                case 'E':
                    cout << "Finished. Thank you!" << endl;
                    break;
                case 'e':
                    cout << "Finished. Thank you!" << endl;
                    break;
                default:
                    goto calculationProcess;
        }
    }
}