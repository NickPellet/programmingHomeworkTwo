#include <iostream>
using namespace std;
int main() {

    //Variable Initialization

    double num1, num2;
    char sign, choice;
    bool runAgain = true;
    calculationProcess:
        do {
    
    // Gets numbers and operators from the user

            cout << "Please enter two numbers: "<< endl;
            cin >> num1 >> num2;
            cout << "Please enter an operator (+, -, *, /): " << endl;
            cin >> sign;

    // Checks if user is dividing by zero, restarts program if so

            if (num2 == 0 && sign == '/') {
                cout <<  "Invalid Input. Cannot divide by zero." << endl;
                goto calculationProcess;
            }

    // Performs and displays calculations

            if (sign == '+')
                cout << num1 << " + " << num2 << " = " << num1 + num2 << endl;
            else if (sign == '-')
                cout << num1 << " - " << num2 << " = " << num1 - num2 << endl;
            else if (sign == '*')
                cout << num1 << " * " << num2 << " = " << num1 + num2 << endl;
            else if (sign == '/')
                cout << num1 << " / " << num2 << " = " << num1 / num2 << endl;
            else{
                cout << "Invalid Input" <<  endl;
                goto calculationProcess;
            }

    // Asks user if they want to run the program again

            cout << "Enter 'E' to exit, or anything else to continue" << endl;
            cin >> choice;
            if (choice == 'e' || choice == 'E')
                runAgain = false;
        } while (runAgain == true);
    cout << "Finished. Thank you!" << endl;
    /*
    An issue I faced with this section was getting it to actually repeat. Originally, my code looked like the following
        cout << "Enter 'E' to exit, or anything else to continue" << endl;
        cin << choice;
    }while (choice != 'e' || choice != 'E');
    
    For some reason, this just wouldn't work. It would just always restart no matter what I put in
    I checked for examples of sentinel while loops in C++, and noticed that a lot of them used boolean variables
    I created a boolean and used it for the sentinel control instead, and it worked like a charm, so thats what I stuck with.
    */
}